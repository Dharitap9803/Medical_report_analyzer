import React from 'react';
import '../Home/Home.css';
import HeroImg from '../../assets/MAIN.jpg';

const Home = () => {
  return (
    <section className="main">
      <div className="left-container">
        <div className="text">
          
        </div>
      </div>
    </section>
  );
}

export default Home;
