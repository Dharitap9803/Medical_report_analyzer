import React from 'react'
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import '../Navigation/Navigation.css'

const Navigation = () => {
    return (
        <section className='navbar'>
            <div className="container">
                <div className="name">
                    <h1>REPORT ANALYZER</h1>
                </div>
                <div className="links">
                    <div className='link'>
                        <Link to="/">Home</Link>
                    </div>
                    <div className='link'>
                        <Link to="/ReportAnalyzer">Report Analyzer</Link>
                    </div>
                    <div className='link'>
                        <Link to="/Contact">Contact Us</Link> 
                    </div>
                    <div className='link'>
                        <Link to="/about">About Us</Link>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Navigation