import React from 'react';
import { FaCloudUploadAlt } from "react-icons/fa";
import './ReportAnalyzer.css';
import image from'../../assets/image.jpg';
// import contactimg from '../../assets/contact.png';

const ReportAnalyzer = () => {
  return (
    <div className="card-container">
      {/* First Card: Upload Lab Report */}
      <div className="card1">
        <h2 className="title">Upload Lab Report</h2>
        <p className="subtitle">Please attach a lab report to proceed</p>

        <div className="upload-section">
          <button className="upload-button">
            <FaCloudUploadAlt />
            <span>Upload Lab Report</span>
          </button>
        </div>

        <div className="divider"></div>

        <div className="attached-section">
          <p className="attached-title">Attached Lab Report</p>
          <p className="attached-placeholder">Uploaded lab report will be shown here</p>
        </div>

        <button className="continue-button">CONTINUE</button>
      </div>

  
      <div className="card2">
        <h2 className="card-title">Guide to upload a lab report</h2>
        <div className="card-content">
          <img
            src={image} 
            className="card-image"
          />
          <ul className="card-instructions">
            <li>Don't crop out any part of the image</li>
            <li>Avoid blurred image</li>
            <li>Supported files type: jpeg, jpg, png, pdf</li>
            <li>Maximum allowed file size: 2MB</li>
          </ul>
        </div>
      </div>
    </div>  
  );
};

export default ReportAnalyzer;
