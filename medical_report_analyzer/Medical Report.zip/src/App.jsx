import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './Components/Home/Home';
import About from './Components/About/About';
import Navigation from './Components/Navigation/Navigation';
import Contact from './Components/Contact/Contact';
import ReportAnalyzer from './Components/ReportAnalyzer/ReportAnalyzer';


function App() {
  return (
    <Router>
      <Navigation />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path='/Contact' element ={<Contact/>}/>
        <Route path="/about" element={<About />} />
        <Route path='/ReportAnalyzer' element={<ReportAnalyzer/>}/>
      </Routes>
    </Router>
  );
}

export default App;
